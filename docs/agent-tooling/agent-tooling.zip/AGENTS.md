# AGENTS.md

This file defines the Sniptale workflow.
Use `docs/engineering/implementation-rules.md` for technical decisions.
This file uses ASD-STE100 writing principles.
Project terms, commands, paths, and review labels are technical names.

## Terms

| Term | Meaning |
| --- | --- |
| Owner | The code area responsible for a behavior. |
| Consumer | A caller or component that uses the affected code or contract. |
| Invariant | A condition that must remain true. |
| Candidate | The changes under review. |
| Proof | Tests, checks, or observations that establish the required result. |
| Scope manifest | The record of acceptance criteria, non-goals, planned files, and consumers. |
| Escaped defect | A defect that existing QA did not detect. |
| Test harness | Tools and test pages that support tests. |
| Closeout | The final QA procedure that controls the build and commit. |
| Classified change seam | A change that the change-risk report identifies at a boundary. |
| `tool-noise` | A record of a proven false positive in a guardrail. |
| QA | Quality assurance. |
| UI | User interface. |
| DPR | Device pixel ratio. |
| MV3 | Manifest V3. |

## Task Scope

- Before implementation, record the acceptance criteria, non-goals, planned files, and consumers.
- Define acceptance criteria as results that you can observe.
- Do not assume that a task is urgent.
- Increase scope only for an acceptance criterion, established defect, existing invariant, reachable supported flow, or material risk.
- Material risks concern security, privacy, authorization, trust boundaries, or permanent data loss.
- Preserve changes outside the task scope.

## Working Directory and Permissions

- Use the current working directory unless the user selects another directory.
- Do not create a Git worktree without explicit permission from the user.
- This rule applies to shell commands, tools, and subagents.
- A request to implement, test, review, or commit does not give this permission.
- Before you change files, check the current Git state.
- This `AGENTS.md` is a local file that Git ignores.
- Do not add this file to Git.
- Use only the command permissions that the current environment permits.
- If a command fails with a permission error, identify the cause first.
- If the environment permits escalation and the failure requires it, use escalated permissions.
- If another document requires unavailable permissions, obey the current environment limits.

## Workflow Selection

- For analysis without file changes, report the findings and their evidence.
- Do not run implementation or commit procedures for analysis without file changes.
- For changes to local ignored instructions only, check the changed files directly.
- Do not run QA wrappers for unrelated changes in the Git diff.
- For changes that Git tracks, use the QA procedure below.
- If the user requests changes without a commit, complete the applicable proof and review.
- Then stop before `qa:closeout` and report that closeout was not run.

## Implementation Planning

- Convert the user request into acceptance criteria.
- Determine the necessary scenarios, tolerances, and edge cases.
- Do not require the user to select an algorithm.
- Do not increase requirements without evidence.
- Give each precision requirement a tolerance with a reason.
- Unknown accuracy does not require zero error.
- Keep established defects, hypotheses, and implementation choices separate.
- Test a hypothesis before you use it as an architecture constraint.
- For each investigation, define the question, smallest useful check, and decision that ends the investigation.
- Continue only if an unanswered question affects acceptance, an established defect, or a material risk.
- Stop when the evidence is sufficient for the task decision.
- Start with the simplest approach that meets acceptance criteria and existing invariants.
- Add infrastructure only if evidence shows a limitation of that approach.
- Before implementation, define the behavior after a failure.
- Preserve valid source data and completed work.
- Restrict only the operations that the failure affects.
- Divide work into steps that you can check separately.
- Complete proof for each step before you start an independent step.
- Combine steps when a dependency requires it.
- Complete required review and closeout for the finished task.
- If the user requests separate commits, use separate closeout runs.
- For interactive changes, use the UI patterns from adjacent flows.
- Check the actual interaction before QA wrappers that block completion.
- Check selection, navigation, editing, and recovery where the change affects them.
- Check the requested result with acceptance proof.
- Tests of implementation logic or internal state alone do not prove the user result.

## Documentation

- For changes to English documentation, use `$asd-ste100`.
- Use the mode that matches the document type.
- During a language rewrite, preserve requirements, conditions, exceptions, technical names, and commands.
- After a language rewrite, run the skill's linter.
- Use `scripts/ste-lint.py` from the installed skill.
- Check meaning separately because the linter does not compare requirements.
- Do not claim full dictionary compliance from a structural check.

## Preflight

Before implementation, run preflight if the task changes any of these items:

- Production behavior or public contracts.
- Persistence or runtime boundaries.
- Permissions or topology.
- QA tooling or more than one owner.

For the planned paths, run `npm run qa:preflight -- --files <paths...>`.
Use the reported owners, risks, documents, consumers, and proof requirements to complete the plan.
`qa:checkpoint` checks preflight again for the completed diff.
It does not replace preflight before implementation when the conditions above apply.
If implementation exceeds the recorded scope, run preflight again before you change the additional scope.

Before code changes, read the applicable rules in `docs/engineering/implementation-rules.md`.
If the owner or file location is unclear, read `docs/architecture/repository-overview.md`.
Read the applicable sections of these documents:

| Change | Document |
| --- | --- |
| Runtimes or ownership across runtimes | `docs/architecture/runtime-contexts.md` |
| Topology, names, or file splits | `docs/architecture/code-organization.md` |
| Differences from platform patterns | `docs/architecture/platform-patterns-and-tradeoffs.md` |
| Translated UI or locale behavior | `docs/architecture/i18n-architecture.md` |
| Parsing, snapshots, traversal, export, or apply-back | `docs/architecture/parser-architecture.md` |
| Product UX or extension UI | `DESIGN.md` |
| Credentials, sensitive storage, diagnostics, tracing, or secret headers | `docs/security/data-handling.md` |
| Extension permissions or manifest capabilities | `docs/security/manifest-permissions.md` |

## Broad Moves

A broad move adds, moves, or renames files across an owner boundary.
A change to a public import path is also a broad move.
Before implementation, make a complete inventory of these items:

- Each affected file and consumer.
- Each owner boundary and public contract.
- Typecheck scope and name or path collisions.
- Rollback, file modes, and content digests.
- Risks and required proof.

Before a planned broad move, run `$topology-plan-review`.
If a broad move has no prior topology review, run that review after all required proof passes.

## UI Viewport Proof

Use this section for changes to UI flows or desktop layout.

- Use CSS page viewports.
- Use **1280×560** and **1920×900** as the primary sizes.
- Additional presets are **1366×600**, **1536×700**, and **2560×1280**.
- Heights are test budgets, not OS conversions.
- Do not subtract browser chrome.
- Do not use DPR to simulate OS scaling.
- Set the viewport before navigation.
- For manual persistent contexts in MV3, set the viewport and DPR explicitly.
- Use the presets in `tooling/test/e2e/support/browser-viewport.ts`.
- If a test sets its own viewport, use that viewport.

For a selected spec, use this command:

```sh
SNIPTALE_E2E_VIEWPORT=1280x560 npm exec playwright test -- <spec>
```

The default viewport is **1920×900**.
For specs that use harness pages, first build with `npm run qa:e2e:build`.
Build once for the unchanged inputs.
Then use this command:

```sh
SNIPTALE_EXTENSION_BUILD_DIR=.tmp/e2e-builds/test SNIPTALE_E2E_VIEWPORT=1280x560 npm exec playwright test -- <spec>
```

The default `dist` build can omit test harness pages.
If missing harness pages prevent startup, this failure does not prove a product regression.

- For desktop layout changes, check both primary sizes.
- For desktop layout changes, check widths B−1, B, and B+1 at each applicable breakpoint B.
- For desktop layout changes, check horizontal scroll at a width below 1280.
- At short heights, operate the modal and footer controls through their actual scroll owners.
- Add intermediate presets only if the changed flow requires them.
- Do not increase unrelated test suites.
- Save each screenshot with `path: info.outputPath("name.png")` and `fullPage: false`.
- The line reporter can lose attachments that contain only a buffer in passing runs.
- Inspect screenshots after the UI settles, before you finalize tests and start QA wrappers that block completion.

## Implementation

- For an escaped defect, add proof that fails before you fix the defect.
- Record why existing QA missed the defect.
- Record whether the defect requires a deterministic guard.
- If formatting is necessary, use only `npm run format:write`.
- Do not run it routinely before `qa:checkpoint`.
- Do not use a formatter on authored Markdown.
- Change generated legal text only through its generator or digest owner.
- If subagents are available, you may assign independent investigation, diagnosis, or implementation work.
- The main thread runs all QA wrappers that block completion.

## Persistence Concurrency Proof

For persistence changes, record these cases in the scope manifest:

- Parallel writers.
- Delayed writes after deletion or restore.
- Recreation of the same identity.
- Command retry after failure or refusal.

For each applicable case, state the invariant and the test file and test name.
For each inapplicable case, give a short reason from the supported flow.
Include opening operations that can write before an editor session exists.
Use controlled ordering in tests. Do not use timing delays to create the race.

The reviewer checks the case selection, test evidence, and reasons for inapplicable cases.
Checkpoint must execute the selected tests through existing affected-test discovery or the owner map.
If selection misses a test, correct the existing owner map and prove execution through checkpoint.
Do not add a separate advisory report or a heuristic race detector.

## QA and Closeout

Complete these steps in order for changes that Git tracks.
Repeat a step only if a later edit makes its result invalid.

1. Complete the candidate and deterministic proof for the required success and failure paths.
2. If preflight reports harness or shared-control files, run `npm run qa:release-harness`.
3. Run `npm run qa:checkpoint`.
4. Complete the reviews that the change-risk report and actual implementation require.
5. Collect all review findings before corrections. Check each finding against acceptance criteria, evidence, and invariants.
6. Apply one correction batch. Repeat proof and review where the correction makes their results invalid.
7. Unless the user requested no commit, run `npm run qa:closeout -- -m "<commit message>"`.

`qa:closeout` controls checkpoint reuse, build, diff validation, staging, and commit.
Unless the user requests an exception, apply these restrictions:

- Do not stage files manually.
- Do not run QA wrappers that block completion at the same time.
- Do not stage `tasks/**`.
- Do not amend a commit.
- Do not replace closeout with another procedure.

If closeout fails, diagnose only the failed stage.
Fix local defects.
Run closeout again.
If the failure identifies incorrect ownership, topology, proof scope, or runtime boundaries, return to preflight.

## Review

- Run every `$security-code-review` and `$architecture-code-review` that the change-risk report requires.
- This requirement applies even though the wrappers do not store or enforce review completion.
- Missing review routing or classified change seams does not prove low risk or cancel required review.
- If the report does not route a review, check the actual implementation against both review-skill triggers.
- Run each applicable review.
- If a review does not apply, record the reason from the actual implementation.
- For each required review, use a new subagent that can only read files.
- Set `fork_turns: "none"`.
- Give the reviewer the scope manifest, exact diff, preflight result, and QA results.
- Do not give the reviewer intended conclusions.
- Require new behavior or proof only for a reachable trigger that affects acceptance or a material invariant.
- Repeat review only if corrections change behavior, ownership, public contracts, dependency direction, parser semantics, or security.
- Treat heuristic findings as items to investigate.
- Fix established defects.
- Inspect the flagged implementation first.
- Investigate the applicable guardrail only if concrete evidence suggests a false positive.
- Establish that evidence before you request an allowance or exception.
- If evidence proves a false positive, record it as exact `tool-noise`.
- Include its owner, reason, and removal condition.
- Do not add debt to a baseline.
- Do not weaken a rule.
- Do not add a broad exception.

Classify each finding with the first definition that applies:

1. `security issue`: Evidence shows a material risk within the task scope.
2. `current regression`: The candidate introduced or made worse a defect that is not a security issue.
3. `acceptance blocker`: Another condition prevents an acceptance criterion.
4. `pre-existing hardening`: The condition does not prevent acceptance, and the candidate did not make it worse.

The first three classes prevent completion.
Report `pre-existing hardening` only if it affects a task decision or the user requests it.

## Unavailable Checks

If a required tool, reviewer, or check is unavailable, preserve completed work.
Continue the work that does not depend on the missing result.
Report the exact blocker and the remaining required action.
Do not cancel the requirement.
Do not report completion without its result.

## Final Report

Under `auto_review`, you have permission to send Sniptale task reports to the user's orchestrator chat.
No additional permission is necessary for these reports.
Reports can include changes, commits, QA results, review results, and blockers.
Do not send secrets or personal data.

Report these items:

- The change.
- Each required QA and closeout command with status `passed`, `failed`, or `not run`.
- The checkpoint risk level, `no classified change seams detected`, or `not run`.
- Each review result, or `not required` with a reason from the actual implementation.
- For an escaped defect, why QA missed it and the decision about a deterministic guard.

After the fourth closeout attempt, also report repeated causes and any resulting documentation or guardrail changes.
