# Sniptale product design entry

Read the [canonical design rules](docs/design/index.md) for product UI changes. Read only the applicable group and cross-cutting rules.

Inspect the corresponding [working reference](tooling/design-reference/index.html) and the actual product surface before implementation.

The extension popup retains its specific interface. Preserve specialized timeline, canvas, paint, and resource interactions.

The design rules live under docs/design. This local file contains routing only. Agent-tooling distribution remains a separate task.
